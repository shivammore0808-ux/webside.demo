// EDIT THESE SETTINGS BEFORE PUBLISHING
const WELORA_CONFIG = {
  // WhatsApp number with country code, digits only. Example for India: 919876543210
  whatsappNumber: "",
  // Add the official agency email when available, e.g. "hello@weloraagency.com"
  email: ""
};

document.addEventListener("DOMContentLoaded", () => {
  const loader = document.querySelector(".loader");
  window.addEventListener("load", () => setTimeout(() => loader?.classList.add("loaded"), 350));

  document.getElementById("year").textContent = new Date().getFullYear();

  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");
  menuButton.addEventListener("click", () => {
    const expanded = menuButton.getAttribute("aria-expanded") === "true";
    menuButton.setAttribute("aria-expanded", String(!expanded));
    menuButton.setAttribute("aria-label", expanded ? "Open navigation" : "Close navigation");
    nav.classList.toggle("open", !expanded);
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
  }));

  // Portfolio category filters
  const filters = document.querySelectorAll(".filter");
  const workCards = document.querySelectorAll(".work-card");
  filters.forEach(button => button.addEventListener("click", () => {
    filters.forEach(item => item.classList.toggle("active", item === button));
    const category = button.dataset.filter;
    workCards.forEach(card => card.classList.toggle("hidden", category !== "all" && card.dataset.category !== category));
  }));

  // Contact configuration: WhatsApp is the primary form destination; email is the fallback.
  const emailLink = document.getElementById("email-link");
  const whatsappLink = document.getElementById("whatsapp-link");
  if (WELORA_CONFIG.email) {
    emailLink.href = `mailto:${WELORA_CONFIG.email}`;
    emailLink.textContent = WELORA_CONFIG.email;
  }
  if (WELORA_CONFIG.whatsappNumber) {
    whatsappLink.href = `https://wa.me/${WELORA_CONFIG.whatsappNumber}`;
    whatsappLink.target = "_blank";
    whatsappLink.rel = "noopener";
    whatsappLink.textContent = "Chat with us ↗";
  }

  document.getElementById("contact-form").addEventListener("submit", event => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const message = [
      "Hello WELORA AGENCY! I'd like to discuss a project.",
      `Name: ${data.get("name")}`,
      `Business: ${data.get("business")}`,
      `Phone: ${data.get("phone")}`,
      `Service: ${data.get("service")}`
    ].join("\n");

    if (WELORA_CONFIG.whatsappNumber) {
      const url = `https://wa.me/${WELORA_CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`;
      window.open(url, "_blank", "noopener,noreferrer");
      document.getElementById("form-note").textContent = "Your enquiry has been prepared in WhatsApp. Send the message there to complete your enquiry.";
    } else if (WELORA_CONFIG.email) {
      const subject = encodeURIComponent("New project enquiry — WELORA AGENCY");
      window.location.href = `mailto:${WELORA_CONFIG.email}?subject=${subject}&body=${encodeURIComponent(message)}`;
      document.getElementById("form-note").textContent = "Your email app should open with the enquiry details. Send the email to complete your enquiry.";
    } else {
      document.getElementById("form-note").textContent = "Form preview is working. Add your WhatsApp number or official email in script.js to receive enquiries.";
      alert("Please configure the agency WhatsApp number or email in script.js before receiving enquiries.");
    }
  });

  // Subtle scroll reveals, with reduced-motion support.
  const revealTargets = document.querySelectorAll(".section-kicker, .intro-grid, .values-row, .section-heading, .service-card, .why-layout, .benefit-grid > div, .work-card, .process-grid article, .contact-grid");
  revealTargets.forEach(element => element.classList.add("reveal"));
  if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealTargets.forEach(element => observer.observe(element));
  } else {
    revealTargets.forEach(element => element.classList.add("visible"));
  }
});
