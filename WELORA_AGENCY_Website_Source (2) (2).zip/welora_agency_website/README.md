# WELORA AGENCY website

A responsive static website built with HTML, CSS and vanilla JavaScript. The supplied WELORA logo is included in `assets/welora-logo.jpeg`.

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a browser. For best results, use VS Code with the Live Server extension.

## Important: configure contact details
Open `script.js` and edit the `WELORA_CONFIG` object:

```js
const WELORA_CONFIG = {
  whatsappNumber: "919876543210", // replace with your real number; digits only, include country code
  email: "hello@example.com"      // replace with your official email
};
```

The contact form validates the fields and prepares an enquiry message for WhatsApp. If WhatsApp is not configured but an email is, it uses the visitor's email app. This is a front-end integration, not a database-backed form. For direct submissions without WhatsApp/email apps, connect a form backend such as Formspree or your own server endpoint.

## Customize the portfolio
The four portfolio tiles are editable concept placeholders, not real client work. Replace the `.mock-art` blocks in `index.html` with your approved project images and update their captions. Keep the `data-category` values (`social`, `reels`, `brand`, `ads`) to preserve filtering.

## Publish
Upload the extracted folder contents to your hosting provider (for example, GitHub Pages, Netlify or your web hosting file manager). Keep the `assets` folder beside `index.html`.

## Included files
- `index.html` — page structure and content
- `style.css` — responsive visual design and animations
- `script.js` — mobile menu, portfolio filters, reveal effects and enquiry flow
- `assets/welora-logo.jpeg` — supplied brand logo
